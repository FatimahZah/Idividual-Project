#include <iostream>
#include <fstream> // to create and write info to files in storage
#include <string> // to use string datatype 
#include <conio.h> // to use system("cls") and getch()
#include <windows.h> // to enhance and enable program compatibility and interaction with OS or filesystem
using namespace std;




//Creating class for airlines database
class Airlines
{
    private :
//	final String PATH = "src/databases/airlines.csv";

    /**
     * Instance variables
     */
     string airlineID;
      string name;
      string Alias;
      string IATA;
      string ICAO;
      string callsign;
      string country;
     double active;


    public:
		 Airlines()
		{
        this -> airlineID = airlineID;
        this->name = name;
        this->Alias = Alias;
        this->IATA = IATA;
        this->ICAO = ICAO;
        this->callsign = callsign;
        this->country = country;
		}

    /**
     * setters for the airlines
     */
	   void setAirlineID( string airlineID) {
	        this->airlineID = airlineID;
	    }
	
	   void setAlias( string alias) {
	        Alias = alias;
	    }
	
	     void setActive(double active) {
	        this->active = active;
	    }
	
	     void setCallsign( string callsign) {
	        this->callsign = callsign;
	    }
	
	     void setCountry( string country) {
	        this->country = country;
	    }
	
	      setIATA( string IATA) {
	        this->IATA = IATA;
	    }
	
	     void setICAO( string ICAO) {
	        this->ICAO = ICAO;
	    }
	
	     void setName(string name) {
	        this->name = name;
	    }
	
	    /**
	     * generating getters
	     *
	     * @return
	     */
	     double getActive() {
	        return active;
	    }
	
	      string getAirlineID() {
	        return airlineID;
	    }
	
	      string getAlias() {
	        return Alias;
	    }
	
	      string getCallsign() {
	        return callsign;
	    }
	
	      string getCountry() {
	        return country;
	    }
	
	      string getIATA() {
	        return IATA;
	    }
	
	      string getICAO() {
	        return ICAO;
	    }
	
	      string getName() {
	        return name;
	    }
};

//creating class for Aitports database

class Airports
{
    /**
     * Instances variables or fields
     */

    private :
	// final String PATH = "src/databases/airports.csv";
     string airportID;
    string name;
     string city;
    string country;
     string IATA;
     string ICAO;
     double latitude;
     double longitude;
     double timezone;
     string DST;
     string TzDatabase;
     string type;
     string source;


    public:
	 Airports()
	 {
        this->airportID = airportID;
        this->name = name;
        this->city = city;
        this->country = country;
        this->IATA = IATA;
        this->ICAO = ICAO;
        this->latitude = latitude;
        this->longitude =longitude;
        this->timezone = timezone;
        this->DST = DST;
        this->TzDatabase =TzDatabase;
        this->type = type;
       this->source = source;}

    /**
     * Getters and setter
     */

   string getAirportID() {
        return airportID;
    }

    Airports setAirportID(string airportID) {
        this->airportID = airportID;
        return *this;
    }

   string getName() {
        return name;
    }

     Airports setName(string name) {
        this->name = name;
        return *this;
    }

    string getCity() {
        return city;
    }

     Airports setCity(string city) {
        this->city = city;
        return *this;
    }

    string getCountry() {
        return country;
    }

     Airports setCountry(string country) {
        this->country = country;
        return *this;
    }

   string getIATA() {
        return IATA;
    }

     Airports setIATA(string IATA) {
        this->IATA = IATA;
        return *this;
    }

  string getICAO() {
        return ICAO;
    }

     Airports setICAO(string ICAO) {
        this->ICAO = ICAO;
        return *this;
    }

    double getLatitude() {
        return latitude;
    }

     Airports setLatitude(double latitude) {
        this->latitude = latitude;
        return *this;
    }

     double getLongitude() {
        return longitude;
    }

     Airports setLongitude(double longitude) {
        this->longitude = longitude;
        return *this;
    }

     double getTimezone() {
        return timezone;
    }

     Airports setTimezone(double timezone) {
        this->timezone = timezone;
        return *this;
    }

    string getDST() {
        return DST;
    }

     Airports setDST(string DST) {
        this->DST = DST;
        return *this;
    }

   string getTzDatabase() {
        return TzDatabase;
    }

     Airports setTzDatabase(string tzDatabase) {
        TzDatabase = tzDatabase;
        return *this;
    }

   string getType() {
        return type;
    }

     Airports setType(string type) {
        this->type = type;
        return *this;
    }

   string getSource() {
        return source;
    }

     Airports setSource(string source) {
        this->source = source;
        return *this;
    }
    
};


//Creating class to represent routes database

class Routes{
    /**
     * Instances of varibles
     */

   // private static final HashMap<String, ArrayList<String>> allPossibleRoutes = new HashMap<>();

    private:
	// final String PATH = "src/databases/routes.csv";
   string airline;
     string airlineID;
     string sourceAirport;
     string sourceAirportID;
     string DestinationAirport;
     string codeshare;
     int stops;
    string equipment;

    //Routes(){}
    Routes( string airline,  string airlineID,  string sourceAirport, string sourceAirportID,
                   string DestinationAirport, string codeshare, int stops, string equipment){
        this->airline = airline;
        this->airlineID = airlineID;
        this->sourceAirport = sourceAirport;
        this->sourceAirportID = sourceAirportID;
        this->DestinationAirport = DestinationAirport;
        this->codeshare = codeshare;
        this->stops = stops;
        this->equipment = equipment;
    }

    /**
     * getters and setters
     */
     string getAirline() {
        return airline;
    }

     Routes setAirline( string airline) {
        this->airline = airline;
        return *this;
    }

     string getAirlineID() {
        return airlineID;
    }

     Routes setAirlineID( string airlineID) {
        this->airlineID = airlineID;
        return *this;
    }

   string getSourceAirport() {
        return sourceAirport;
    }

     Routes setSourceAirport( string sourceAirport) {
        this->sourceAirport = sourceAirport;
        return *this;
    }

     string getSourceAirportID() {
        return sourceAirportID;
    }

     Routes setSourceAirportID( string sourceAirportID) {
        this->sourceAirportID = sourceAirportID;
        return *this;
    }

    string getDestinationAirport() {
        return DestinationAirport;
    }

     Routes setDestinationAirport( string destinationAirport) {
        DestinationAirport = destinationAirport;
        return *this;
    }

     string getCodeshare() {
        return codeshare;
    }

     Routes setCodeshare( string codeshare) {
        this->codeshare = codeshare;
        return *this;
    }

     int getStops() {
        return stops;
    }

     Routes setStops(int stops) {
        this->stops = stops;
        return *this;
    }

      string getEquipment() {
        return equipment;
    }

     Routes setEquipment( string equipment) {
        this->equipment = equipment;
        return *this;
    }

};
	

int main()

 
{  



//creating and opening input file
	ifstream input_file;
	input_file.open("johannesburg-yellowknife.txt", ios::in);
	//check if file opened
	if(input_file.fail())
	{
		cerr << "Error failed to open accra-winnipeg.txt" << endl;
	}
	 // reading input file to variable
	 while(! input_file.eof())
	 {
	 	string flight_info;
	 	
	  getline(input_file,flight_info);
	  
	  cout << flight_info << endl;
	 	
	 	
	 }
	 
	 
	 
	 //creating file for output
	ifstream output_file;
	output_file.open("johannesburg-yellowknife_output.txt", ios::in);
	//check if file opened
	if(output_file.fail())
	{
		cerr << "Error failed to open accra-winnipeg_output.txt" << endl;
	}
	 // reading input file to variable
	 while(! output_file.eof())
	 {
	 	string flight_series;
	 	
	  getline(output_file,flight_series);
	  
	  cout <<endl<< flight_series << endl;
	 	
	 	
	 }
	 output_file.close();
	 
	 

	
	return 0;
}

